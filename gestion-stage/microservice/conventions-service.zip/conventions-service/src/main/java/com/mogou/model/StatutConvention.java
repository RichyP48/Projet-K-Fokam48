package com.mogou.model;

public enum StatutConvention {
    BROUILLON,
    EN_ATTENTE_VALIDATION,
    VALIDEE,
    SIGNEE,
    FINALISEE
}
