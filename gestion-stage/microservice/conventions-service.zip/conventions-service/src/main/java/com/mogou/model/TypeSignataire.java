package com.mogou.model;

public enum TypeSignataire {
    ETUDIANT,
    ENTREPRISE
}
